#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
#include <windows.h>

using namespace std;

string toLowCase(string text){

    for(int i = 0;i< text.size();i++){
        char symb = text[i];
        int a = symb;
        if(text[i] >= -64 && text[i] <= -33){
            text[i] = a + 32;
        }
    }
    return text;
}

string onlyLetters(string text, int n)
{
    string new_text = "";


    for (int i = 0; i < n; i++)
    {
        if (int(text[i]) == -72 || int(text[i]) == -88 || (int(text[i]) >= -64 && int(text[i]) <= -1))
           new_text += text[i];

    }

    return new_text;
}

int gl_gl(string text, int n)
{
    int ctn = 0;
    bool last_gl = false;

    int f = text[0];

    if (f == -32 || f == -27 || f == -72 || f == -24 || f == -18 || f == -13 || f == -5 || f == -3 || f == -2 || f == -1)
        last_gl = true;

    for(int i = 1; i < n; i++)
    {
        if ((text[i] == -32 || text[i] == -27 || text[i] == -72 || text[i] == -24 || text[i] == -18 || text[i] == -13 || text[i] == -5 || text[i] == -3 || text[i] == -2 || text[i] == -1) && last_gl)
        {
            ctn++;
            last_gl = true;
        }

        else if (text[i] == -32 || text[i] == -27 || text[i] == -72 || text[i] == -24 || text[i] == -18 || text[i] == -13 || text[i] == -5 || text[i] == -3 || text[i] == -2 || text[i] == -1)
            last_gl = true;
        else
            last_gl = false;
    }


    return ctn;

}

int sgl_sgl(string text, int n)
{
    int ctn = 0;
    bool last_sgl = false;

    int f = text[0];

    if (f != -32 && f != -27 && f != -72 && f != -24 && f != -18 && f != -13 && f != -5 && f != -3 && f != -2 && f != -1 && f != -6 && f != -4)
        last_sgl = true;

    for(int i = 1; i < n; i++)
    {
        if ((text[i] != -32 && text[i] != -27 && text[i] != -72 && text[i] != -24 && text[i] != -18 && text[i] != -13 && text[i] != -5 && text[i] != -3 && text[i] != -2 && text[i] != -1 && text[i] != -6 && text[i] != -4) && last_sgl)
        {
            ctn++;
            last_sgl = true;
        }

        else if (text[i] != -32 && text[i] != -27 && text[i] != -72 && text[i] != -24 && text[i] != -18 && text[i] != -13 && text[i] != -5 && text[i] != -3 && text[i] != -2 && text[i] != -1 && text[i] != -4 && text[i] != -6)
            last_sgl = true;
        else
            last_sgl = false;
    }


    return ctn;

}

int gl_sgl (string text, int n)
{
    int f = text[0];
    bool last_gl = false;
    bool last_sgl = false;
    int ctn = 0;

    if (f == -32 || f == -27 || f == -72 || f == -24 || f == -18 || f == -13 || f == -5 || f == -3 || f == -2 || f == -1)
        last_gl = true;
    else if (f != -32 && f != -27 && f != -72 && f != -24 && f != -18 && f != -13 && f != -5 && f != -3 && f != -2 && f != -1 && f != -6 && f != -4)
        last_sgl = true;


    for (int i = 1; i < n; i++)
    {
        if (last_sgl && (text[i] == -32 || text[i] == -27 || text[i] == -72 || text[i] == -24 || text[i] == -18 || text[i] == -13 || text[i] == -5 || text[i] == -3 || text[i] == -2 || text[i] == -1))
        {
            last_sgl = false;
            last_gl = true;
        }

        else if (last_gl && (text[i] != -32 && text[i] != -27 && text[i] != -72 && text[i] != -24 && text[i] != -18 && text[i] != -13 && text[i] != -5 && text[i] != -3 && text[i] != -2 && text[i] != -1 && text[i] != -4 && text[i] != -6))
        {
            ctn++;
            last_sgl = true;
            last_gl = false;
        }
    }

    return ctn;
}

int sgl_gl (string text, int n)
{
    int f = text[0];
    bool last_gl = false;
    bool last_sgl = false;
    int ctn = 0;

    if (f == -32 || f == -27 || f == -72 || f == -24 || f == -18 || f == -13 || f == -5 || f == -3 || f == -2 || f == -1)
        last_gl = true;
    else if (f != -32 && f != -27 && f != -72 && f != -24 && f != -18 && f != -13 && f != -5 && f != -3 && f != -2 && f != -1 && f != -6 && f != -4)
        last_sgl = true;


    for (int i = 1; i < n; i++)
    {
        if (last_sgl && (text[i] == -32 || text[i] == -27 || text[i] == -72 || text[i] == -24 || text[i] == -18 || text[i] == -13 || text[i] == -5 || text[i] == -3 || text[i] == -2 || text[i] == -1))
        {
            ctn++;
            last_sgl = false;
            last_gl = true;
        }

        else if (last_gl && (text[i] != -32 && text[i] != -27 && text[i] != -72 && text[i] != -24 && text[i] != -18 && text[i] != -13 && text[i] != -5 && text[i] != -3 && text[i] != -2 && text[i] != -1 && text[i] != -4 && text[i] != -6))
        {
            last_sgl = true;
            last_gl = false;
        }
    }

    return ctn;
}

int main()
{

    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);

    ifstream fin("input.txt");
    ofstream fout("output.txt");
    string text="", b;
    while(!fin.eof())
    {
        getline(fin, b);
        text+=" " + b;
    }
    text.erase(0, 1);
    fout<<text;

    text = toLowCase(text);

    int n = text.size();

    text = onlyLetters(text, n);
    n = text.size();

    int glgl = gl_gl(text, n);
    int sglsgl = sgl_sgl(text, n);
    int glsgl = gl_sgl(text, n);
    int sglgl = sgl_gl(text, n);

    fout << "���-�� ����������, ��� ����� ������� �������:" << glgl << endl;
    fout << "���-�� ����������, ��� ����� ��������� ���������:" << sglsgl << endl;
    fout << "���-�� ����������, ��� ����� ������� ���������:" << glsgl << endl;
    fout << "���-�� ����������, ��� ����� ��������� �������:" << sglgl << endl;



    return 0;
}

