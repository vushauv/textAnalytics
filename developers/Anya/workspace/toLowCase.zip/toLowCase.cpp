void toLowCase(string text){
    ifstream fin("input.txt");
    ofstream fout("output.txt");
    for(int i = 0;i< text.size();i++){
        char symb = text[i];
        int a = symb;
        if(text[i] >= -64 && text[i] <= -33){
            text[i] = a + 32;
        }
    }
}